package com.example.socialmedia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.example.socialmedia.databinding.ActivityMainBinding;
import com.example.socialmedia.fragment.AddFragment;
import com.example.socialmedia.fragment.HomeFragment;
import com.example.socialmedia.fragment.NotificationFragment;
import com.example.socialmedia.fragment.ProfileFragment;
import com.example.socialmedia.fragment.SearchFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.iammert.library.readablebottombar.ReadableBottomBar;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    FirebaseAuth auth = FirebaseAuth.getInstance();
    private final int ID_HOME = 0;

    private final int ID_SEARCH = 1;

    private final int ID_ADD = 2;
    private final int ID_NOTIFICATION = 3;
    private final int ID_PROFILE = 4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Hide Toolbar manually
        //getSupportActionBar().hide();

        setSupportActionBar(binding.toolbar);
        MainActivity.this.setTitle("My Profile");


        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        binding.toolbar.setVisibility(View.GONE);
        transaction.replace(R.id.content, new HomeFragment());
        transaction.commit();


        binding.naviBottomBar.add(new MeowBottomNavigation.Model(ID_HOME, R.drawable.ic_home));
        binding.naviBottomBar.add(new MeowBottomNavigation.Model(ID_SEARCH, R.drawable.ic_magnifier));
        binding.naviBottomBar.add(new MeowBottomNavigation.Model(ID_ADD, R.drawable.ic_add));
        binding.naviBottomBar.add(new MeowBottomNavigation.Model(ID_NOTIFICATION, R.drawable.ic_notification));
        binding.naviBottomBar.add(new MeowBottomNavigation.Model(ID_PROFILE, R.drawable.ic_user));



        binding.naviBottomBar.setOnReselectListener(new MeowBottomNavigation.ReselectListener() {
            @Override
            public void onReselectItem(MeowBottomNavigation.Model item) {

            }
        });

        binding.naviBottomBar.setOnClickMenuListener(new MeowBottomNavigation.ClickListener() {
            @Override
            public void onClickItem(MeowBottomNavigation.Model item) {

                // Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
            }
        });

        binding.naviBottomBar.setOnShowListener(new MeowBottomNavigation.ShowListener() {
            @Override
            public void onShowItem(MeowBottomNavigation.Model item) {

                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

                String name;
                switch (item.getId()) {
                    case ID_HOME:
                        name = "Home";
                        binding.toolbar.setVisibility(View.GONE);
                        transaction.replace(R.id.content, new HomeFragment());
                        break;

                    case ID_SEARCH:
                        name = "Search";
                        binding.toolbar.setVisibility(View.GONE);
                        transaction.replace(R.id.content, new SearchFragment());
                        break;

                    case ID_ADD:
                        name = "Add";
                        binding.toolbar.setVisibility(View.GONE);
                        transaction.replace(R.id.content, new AddFragment());
                        break;

                    case ID_NOTIFICATION:
                        name = "Notification";
                        binding.toolbar.setVisibility(View.GONE);
                        transaction.replace(R.id.content, new NotificationFragment());
                        break;
                    case ID_PROFILE:
                        name = "Profile";
                        binding.toolbar.setVisibility(View.VISIBLE);
                        transaction.replace(R.id.content, new ProfileFragment());
                        break;

                }
                transaction.commit();

            }
        });

        binding.naviBottomBar.setCount(ID_NOTIFICATION, "0");
        binding.naviBottomBar.show(ID_HOME, true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.setting) {

            auth.signOut();
            Intent intent = new Intent(MainActivity.this,LoginActivity.class);
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }
}