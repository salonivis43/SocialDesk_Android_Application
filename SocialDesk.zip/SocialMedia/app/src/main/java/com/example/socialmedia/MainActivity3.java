package com.example.socialmedia;



import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.socialmedia.databinding.ActivityMain2Binding;
import com.example.socialmedia.databinding.ActivityMain3Binding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {

    ActivityMain3Binding binding;

    private List<String> messagesList;
    private ArrayAdapter<String> adapter;

    private static final String USER1 = "user1";
    private static final String USER2 = "user2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMain3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar3);
        MainActivity3.this.setTitle("SocialDesk Community");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        messagesList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, messagesList);
        binding.listViewMessages.setAdapter(adapter);

        binding.btnSendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }

    private void sendMessage() {
        String message = binding.editTextMessage.getText().toString().trim();
        if (!message.isEmpty()) {
            String sender = USER1; // Replace this with the sender's username or ID
            String recipient = USER2; // Replace this with the recipient's username or ID
            String formattedMessage = sender + ": " + message;
            messagesList.add(formattedMessage);
            adapter.notifyDataSetChanged();
            binding.editTextMessage.setText("");
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        finish();
        return super.onOptionsItemSelected(item);
    }
}




