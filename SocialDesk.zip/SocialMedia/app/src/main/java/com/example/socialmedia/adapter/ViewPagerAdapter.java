package com.example.socialmedia.adapter;

import android.annotation.SuppressLint;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.socialmedia.R;
import com.example.socialmedia.fragment.Notification2Fragment;
import com.example.socialmedia.fragment.RequestFragment;

import java.util.ArrayList;
import java.util.Objects;



public class ViewPagerAdapter extends FragmentPagerAdapter {


    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch(position){
            case 0:
                return new Notification2Fragment();
            case 1:
                return new RequestFragment();
            default:
                return null;

        }

    }

    @Override
    public int getCount() {
        return 2;
    }

    @Nullable
    @Override
    public  CharSequence getPageTitle(int position) {
        String title = null;
        if(position == 0){
            title="NOTIFICATION";
        } else if (position == 1) {
            title="REQUEST";
        }
        return title;
    }
}


/*
public class ViewPagerAdapter extends FragmentPagerAdapter {

    ArrayList<Fragment> fragmentArrayList = new ArrayList<>();
    ArrayList<String> tabtitle = new ArrayList<>();
    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

   public void addFragment(Fragment fragment,String title){
        this.fragmentArrayList.add(fragment);
        this.tabtitle.add(title);

    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

            return fragmentArrayList.get(position);
        }

        @Override
        public int getCount () {
            return fragmentArrayList.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position){

        return tabtitle.get(position);

        }


    }


    /*
    // The quantity of tab is fixed
    private static final int FRAGMENT_COUNT = 2;
    // Titles for each tab
    private final String[] titles = new String[FRAGMENT_COUNT];

    Context context;



    @SuppressLint("ResourceType")
    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm.getPrimaryNavigationFragment());
        // Load titles for tab from resourses
        titles[0] = context.getResources().getString(Integer.parseInt("NOTIFICATION"));
        titles[1] = context.getResources().getString(Integer.parseInt("REQUEST"));
    }



    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:return new Notification2Fragment();
            case 1:return new RequestFragment();
            default:return new Notification2Fragment();
        }
    }

    @Override
    public int getItemCount() {
        return FRAGMENT_COUNT;
    }



    public String getItemTitle(int position)
    {
        if(position == 0)
        {
            return titles[0];
        } else if (position == 1) {
            return titles[1];
        }
        return titles[0];
    }

     */

 /*   @Nullable
    @Override
    public  CharSequence getPageTitle(int position) {
        String title = null;
        if(position == 0){
            title="NOTIFICATION";
        } else if (position == 1) {
            title="REQUEST";
        }
        return title;
    }
*/


