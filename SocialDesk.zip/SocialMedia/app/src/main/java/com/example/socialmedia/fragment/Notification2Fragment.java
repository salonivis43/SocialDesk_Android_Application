package com.example.socialmedia.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.socialmedia.R;
import com.example.socialmedia.adapter.NotificationAdapter;
import com.example.socialmedia.model.Notification;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class Notification2Fragment extends Fragment {

    RecyclerView notificationRV;
    FirebaseDatabase database;
    ArrayList<Notification> list;

    public Notification2Fragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = FirebaseDatabase.getInstance();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_notification2, container, false);
        notificationRV = view.findViewById(R.id.notificationRV);
        list = new ArrayList<>();
        /*
        list.add(new Notification(R.drawable.profile1,"<b>Alicia Addams</b> mention you in a comment: Nice Try","just now"));
        list.add(new Notification(R.drawable.deaf,"<b>Janeeleona</b> Liked your picture.","40 minutes ago"));
        list.add(new Notification(R.drawable.cover,"<b>Katherinn</b> Commented on your post.","2 hours"));
        list.add(new Notification(R.drawable.art,"<b>Alicia Addams</b> mention you in a comment: Nice Try","3 hours"));
        list.add(new Notification(R.drawable.profile,"<b>Janeeleona</b> Liked your picture.","3 hours"));
        list.add(new Notification(R.drawable.dennis,"<b>Katherinn</b> Commented on your post.","4 hours"));
        list.add(new Notification(R.drawable.profile1,"<b>Alicia Addams</b> mention you in a comment: Nice Try","4 hours"));
        list.add(new Notification(R.drawable.profile,"<b>Janeeleona</b> Liked your picture.","4 hours"));
        list.add(new Notification(R.drawable.cover,"<b>Katherinn</b> Commented on your post.","4 hours"));
        */



        NotificationAdapter adapter = new NotificationAdapter(list, getContext());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false);
        notificationRV.setLayoutManager(layoutManager);
        notificationRV.setNestedScrollingEnabled(false);
        notificationRV.setAdapter(adapter);

        database.getReference()
                .child("notification")
                .child(FirebaseAuth.getInstance().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                            Notification notification = dataSnapshot.getValue(Notification.class);
                            notification.setNotificationID(dataSnapshot.getKey());
                            list.add(notification);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        return view;
    }
}