package com.example.socialmedia;

public class  API {
    public static String API_URL = "https://api.openai.com/v1/completions";
    public static String API = "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";
}
