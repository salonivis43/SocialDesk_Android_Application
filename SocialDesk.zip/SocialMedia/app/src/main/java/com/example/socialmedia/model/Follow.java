package com.example.socialmedia.model;

public class Follow {

    private String followedBy;
    private String getFollowedAt;

    public Follow() {
    }

    public String getFollowedBy() {
        return followedBy;
    }

    public void setFollowedBy(String followedBy) {
        this.followedBy = followedBy;
    }

    public String getGetFollowedAt() {
        return getFollowedAt;
    }

    public void setGetFollowedAt(String getFollowedAt) {
        this.getFollowedAt = getFollowedAt;
    }
}
